import * as cdk from 'aws-cdk-lib';
import * as connect from 'aws-cdk-lib/aws-connect';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as kms from 'aws-cdk-lib/aws-kms';
import * as kinesis from 'aws-cdk-lib/aws-kinesis';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { KinesisEventSource } from 'aws-cdk-lib/aws-lambda-event-sources';
import { Construct } from 'constructs';

export class Iac100Stack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // Create an input parameter for the instance alias
    const instanceAliasParameter = new cdk.CfnParameter(this, 'instanceAlias', {
      type: 'String',
      description: 'The alias for the Amazon Connect instance'
    });

    // Create a KMS key for encryption
    const encryptionKey = new kms.Key(this, 'ConnectEncryptionKey', {
      description: 'KMS key for Amazon Connect instance and S3 bucket',
      enableKeyRotation: true,
    });

    // Create an S3 bucket for Connect instance storage
    const connectStorageBucket = new s3.Bucket(this, 'ConnectStorageBucket', {
      bucketName: instanceAliasParameter.valueAsString + '-storage-bucket',
      encryption: s3.BucketEncryption.KMS,
      encryptionKey: encryptionKey,
      removalPolicy: cdk.RemovalPolicy.RETAIN,
      autoDeleteObjects: false,
    });

    // Create an Amazon Connect instance
    const connectInstance = new connect.CfnInstance(this, 'ConnectInstance', {
      instanceAlias: instanceAliasParameter.valueAsString,
      identityManagementType: 'CONNECT_MANAGED',
      attributes: {
        inboundCalls: true,
        outboundCalls: true,
    
        // the properties below are optional
        autoResolveBestVoices: true,
        contactflowLogs: true,
        contactLens: true,
        earlyMedia: true,
        useCustomTtsVoices: false,
      }
    });

    const contactRecordsStream = new kinesis.Stream(this, 'ContactRecordsStream', {
      streamName: 'connect-contact-records-stream',
      encryption: kinesis.StreamEncryption.KMS,
      encryptionKey: encryptionKey,
    });

    const agentEventsStream = new kinesis.Stream(this, 'AgentEventsStream', {
      streamName: 'connect-agent-events-stream',
      encryption: kinesis.StreamEncryption.KMS,
      encryptionKey: encryptionKey,
    });

    // create the storage configuration for call recordings
    const callRecordingsStorageConfig = new connect.CfnInstanceStorageConfig(this, 'CallRecordingsStorageConfig', {
      instanceArn: connectInstance.attrArn,
      resourceType: 'CALL_RECORDINGS',
      storageType: 'S3',
      s3Config: {
        bucketName: connectStorageBucket.bucketName,
        bucketPrefix: 'recordings/',
        encryptionConfig: {
          encryptionType: 'KMS',
          keyId: encryptionKey.keyArn
        },
      },
    });

    // create the storage configuration for contact records
    const contactRecordsStorageConfig = new connect.CfnInstanceStorageConfig(this, 'ContactRecordsStorageConfig', {
      instanceArn: connectInstance.attrArn,
      resourceType: 'CONTACT_TRACE_RECORDS',
      storageType: 'KINESIS_STREAM',
      kinesisStreamConfig: {
        streamArn: contactRecordsStream.streamArn
      }
    });

    // Create Lambda functions to process contact records and agent events
    const contactRecordProcessLambda = new lambda.Function(this, 'ContactRecordProcessLambda', {
      functionName: this.stackName + '-connect-contact-record-process-lambda',
      runtime: lambda.Runtime.NODEJS_20_X,
      code: lambda.Code.fromAsset('lambdas'),
      handler: 'contactRecordsProcess.handler',
    });

    const agentEventsProcessLambda = new lambda.Function(this, 'AgentEventsProcessLambda', {
      functionName: this.stackName + '-connect-agent-events-process-lambda',
      runtime: lambda.Runtime.NODEJS_20_X,
      code: lambda.Code.fromAsset('lambdas'),
      handler: 'agentEventsProcess.handler',
    });

    // Associate relevant Kinesis triggers to each Lambda function
    contactRecordProcessLambda.addEventSource(new KinesisEventSource(contactRecordsStream, {
      batchSize: 1, // default
      startingPosition: lambda.StartingPosition.TRIM_HORIZON
    }));

    agentEventsProcessLambda.addEventSource(new KinesisEventSource(agentEventsStream, {
      batchSize: 1, // default
      startingPosition: lambda.StartingPosition.TRIM_HORIZON
    }));

    // create the storage configuration for agent events
    const agentEventsStorageConfig = new connect.CfnInstanceStorageConfig(this, 'AgentEventsStorageConfig', {
      instanceArn: connectInstance.attrArn,
      resourceType: 'AGENT_EVENTS',
      storageType: 'KINESIS_STREAM',
      kinesisStreamConfig: {
        streamArn: agentEventsStream.streamArn
      }
    });

    // Output the Connect instance ARN, S3 bucket name, and KMS key ARN
    new cdk.CfnOutput(this, 'ConnectInstanceArn', {
      value: connectInstance.attrArn,
      description: 'Amazon Connect Instance ARN',
    });

    new cdk.CfnOutput(this, 'ConnectStorageBucketName', {
      value: connectStorageBucket.bucketName,
      description: 'Amazon Connect Storage Bucket Name',
    });

    new cdk.CfnOutput(this, 'EncryptionKeyArn', {
      value: encryptionKey.keyArn,
      description: 'KMS Key ARN for encryption',
    });
  }
}
